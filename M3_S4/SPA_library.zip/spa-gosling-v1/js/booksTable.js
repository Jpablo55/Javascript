import { getBooks, deleteBook, updateBook } from "./services";
import { openModalEdit } from "./modal";

// Render users
export function renderBooks(books) {
    const tbody = document.getElementById("bookTableBody");
    if (!tbody) return;

    tbody.innerHTML = "";

    // ✅ Obtenemos el rol actual
    const userData = JSON.parse(localStorage.getItem("UserData"));
    const isAdmin = userData && userData.role === "Admin";


    books.forEach((book) => {
        const row = document.createElement("tr");
        row.innerHTML = `
            <td><img src="./assets/img/books.png" alt="Avatar" /></td>
            <td>${book.title}</td>
            <td>${book.author}</td>
            <td>${book.isbn}</td>
            <td>${book.dateOfEntry}</td>
            <td>
                ${
                    isAdmin
                        ? (Array.isArray(book.borrowedBy) && book.borrowedBy.length === 0
                            ? `<span style="color:green;">Available</span>`
                            : `<span style="color:red;">Borrowed</span>`)
                        : (Array.isArray(book.borrowedBy) && book.borrowedBy.length === 0
                            ? `<button class="borrow-btn style-borrow" data-id="${book.id}">Borrow</button>`
                            : "Borrowed")
                }
            </td>
            ${isAdmin ? `
                <td>
                    <button class="edit-btn" data-id="${book.id}">
                        <img src="./assets/icons/pencil.png" alt="Edit" class="edit-icon"/>
                    </button>
                    <button class="delete-btn" data-id="${book.id}">
                        <img src="./assets/icons/trash.png" alt="Delete" class="delete-icon"/>
                    </button>
                </td>
            ` : ""}
            `;
        tbody.appendChild(row);
    });
    addRowListeners();
}

export function addRowListeners() {
    document.querySelectorAll(".edit-btn").forEach((btn) => {
        btn.addEventListener("click", () => {
            const id = btn.dataset.id;
            openModalEdit(id);
        });
    });

    document.querySelectorAll(".delete-btn").forEach((btn) => {
        btn.addEventListener("click", async () => {
            const id = btn.dataset.id;
            if (confirm("Are you sure you want to delete this book?")) {
                await deleteBook(id);
                const books = await getBooks();
                renderBooks(books);
            }
        });
    });

    document.querySelectorAll(".borrow-btn").forEach((btn) => {
        btn.addEventListener("click", async () => {

            const id = btn.dataset.id;
            const userData = JSON.parse(localStorage.getItem("UserData"));

            if (!userData) return alert("You must be logged in");
            const books = await getBooks();
            const book = books.find((b) => b.id == id);
            if (!book) return;

            if (book.borrowedBy && book.borrowedBy.length > 0) {
                alert("Book already borrowed!");
                return;
            }

            const updatedBook = {
                ...book,
              borrowedBy: [userData.name], // ✅ lo dejamos como array para que sea compatible con tu db.json
            };

            await updateBook(book.id, updatedBook); // ✅ este debe hacer un PUT o PATCH

            const updatedBooks = await getBooks();
            renderBooks(updatedBooks);
            updateAvailableBooksCount(updatedBooks);
        });
    });
}

export function updateAvailableBooksCount(books) {
    const available = books.filter(book => !book.borrowedBy || book.borrowedBy.length === 0).length;
    const countSpan = document.getElementById("availableCount");
    if (countSpan) countSpan.textContent = available;
}

// Search bar logic
export function setupSearch() {
    const searchInput = document.getElementById("searchInput");
    if (!searchInput) return;

    searchInput.addEventListener("input", async () => {
        const searchTerm = searchInput.value.toLowerCase();
        const allBooks = await getBooks();

        const filtered = allBooks.filter((book) =>
            book.title.toLowerCase().includes(searchTerm)
        );

        renderBooks(filtered);
    });
}