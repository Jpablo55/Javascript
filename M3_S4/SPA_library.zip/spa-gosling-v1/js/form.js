import { createBook, getBooks, updateBook } from "./services";
import { closeModal } from "./modal";
import { renderBooks } from "./booksTable";
import { navigate } from "./navigate";
import { counterId } from "./script";

// FORM LOGIC
export function setListeners() {
    const addBtn = document.getElementById("addBookBtn");
    const closeBtn = document.querySelector(".close-btn");
    const modal = document.getElementById("bookModal");
    const form = document.getElementById("bookForm");

    if (addBtn) {
        addBtn.addEventListener("click", () => navigate("/add_book"));
    }

    if (closeBtn) {
        closeBtn.addEventListener("click", closeModal);
    }

    if (modal) {
        window.addEventListener("click", (e) => {
            if (e.target === modal) closeModal();
        });
    }

    if (form) {
        form.addEventListener("submit", async (e) => {
            e.preventDefault();

            const id = form.bookId.value;
            let borrowedBy = [];

            if (id) {
                const books = await getBooks();
                const existingBook = books.find((b_books) => b_books.id == id);
                borrowedBy = existingBook?.borrowedBy || [];
            }

            const book = {
                "id": id ? id : counterId,
                "title": form.title.value,
                "author": form.author.value,
                "isbn": form.isbn.value,
                "dateOfEntry": formatDateToSave(form.dateOfEntry.value),
                "borrowedBy": borrowedBy,
            };

            // const id = form.bookId.value;
            if (id) {
                await updateBook(id, book);
            } else {
                await createBook(book);
            }

            const Books = await getBooks();
            renderBooks(Books);
            closeModal();
        });
    }
}

export const formatDateToSave = (inputDate) => {
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    const [year, month, day] = inputDate.split("-");
    const monthAbbr = months[parseInt(month, 10) - 1];

    return `${day}-${monthAbbr}-${year}`;
}

export function setDateInputValidation() {
    const dateInput = document.getElementById("dateOfEntry");
    if (dateInput) {
        const today = new Date().toISOString().split("T")[0];
        dateInput.max = today;

        dateInput.addEventListener("input", () => {
            if (dateInput.value > today) {
                alert("You cannot select a future date");
                dateInput.value = today;
            }
        });
    }
}

export function formatDateInput(dateStr) {
    setDateInputValidation();
    const date = new Date(dateStr);
    return date.toISOString().split("T")[0]; // para que funcione en inputs type="date"
}
