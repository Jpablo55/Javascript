import { getBooks } from "./services";
import { formatDateInput } from "./form";

export async function openModalEdit(id) {
    const books = await getBooks();
    const book = books.find((u) => u.id == id);
    if (!book) return;

    document.getElementById("bookId").value = book.id;
    document.getElementById("title").value = book.title;
    document.getElementById("author").value = book.author;
    document.getElementById("isbn").value = book.isbn;
    document.getElementById("dateOfEntry").value=formatDateInput(book.dateOfEntry);

    document.getElementById("modalTitle").textContent = "Edit book";
    document.getElementById("bookModal").style.display = "flex";
}

export function closeModal() {
    const modal = document.getElementById("bookModal");
    modal.style.display = "none";
    // Limpia el formulario cuando se cierra
    const form = document.getElementById("bookForm");
    if (form) {
        form.reset();
        document.getElementById("bookId").value = "";
        document.getElementById("isbn").value = ""; // ⚠ si tienes un campo oculto de isbn
    }
}